/*jsl:option explicit*/
function partial_option_explicit() {
    /* nothing to see here; move along */
    return null;
}
