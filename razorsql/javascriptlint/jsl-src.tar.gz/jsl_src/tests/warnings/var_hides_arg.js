/*jsl:option explicit*/
function var_hides_arg(duplicate) {
    var duplicate; /*warning:var_hides_arg*/
}
