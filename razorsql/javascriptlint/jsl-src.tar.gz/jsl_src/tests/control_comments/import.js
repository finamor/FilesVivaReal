/*jsl:option explicit*/
function cc_import() {
    /*jsl:import    import2.js  */
    return cc_imported;
}
