/*conf:+always_use_option_explicit*/
function always_use_option_explicit() {
    x++; /*warning:undeclared_identifier*/
}
