/*conf:-jscript_function_extensions*/

function conf() {
    this.settings = {};
}

function conf::jscript_function_extensions(val) { /*warning:redeclared_var*//*warning:paren_before_formal*/
}
